
import pandas as pd, re
def normalize_text(s: str) -> str:
    if not isinstance(s, str): return ""
    s = s.lower().strip()
    s = re.sub(r"\d{5,}", "<phone>", s)
    return s
def transform_posts(path='data/sample_posts.csv'):
    df = pd.read_csv(path)
    df['text_norm'] = df['text'].apply(normalize_text)
    return df
if __name__ == '__main__':
    print(transform_posts()[['post_id','text_norm']].head())
