
import pandas as pd
def fetch_mock_posts():
    return pd.read_csv('data/sample_posts.csv')
if __name__ == '__main__':
    print(fetch_mock_posts().head())
