
import pandas as pd, joblib
def load_model(path='data/nlp_model.joblib'):
    try: return joblib.load(path)
    except Exception: return None
def score(text: str, district: str='Chennai') -> float:
    model = load_model()
    base = model.predict_proba([text])[0][1] if model else (0.5 if 'job' in text.lower() else 0.2)
    priors = pd.read_csv('data/tn_districts.csv').set_index('district')['risk_prior'].to_dict()
    prior = float(priors.get(district, 0.5))
    return max(0.0, min(1.0, 0.6*base + 0.4*prior))
