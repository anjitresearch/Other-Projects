
import pandas as pd, joblib
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from ingestion.etl import transform_posts
def train():
    df = transform_posts('data/sample_posts.csv')
    X, y = df['text_norm'], df['label']
    pipe = Pipeline([('tfidf', TfidfVectorizer(max_features=2000, ngram_range=(1,2))),
                     ('clf', LogisticRegression(max_iter=1000))])
    pipe.fit(X, y)
    joblib.dump(pipe, 'data/nlp_model.joblib')
    print('Saved model -> data/nlp_model.joblib')
if __name__ == '__main__':
    train()
