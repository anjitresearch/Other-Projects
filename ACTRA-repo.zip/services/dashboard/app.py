
import os, requests, pandas as pd, streamlit as st, matplotlib.pyplot as plt
API_URL = os.getenv('API_URL','http://localhost:8000')
st.set_page_config(page_title='ACTRA Dashboard', layout='wide')
st.title('ACTRA – Tamil Nadu Risk Dashboard (Demo)')
df = pd.read_csv('data/tn_districts.csv')
col1, col2 = st.columns([2,1])
with col1:
    st.subheader('District Risk Priors')
    st.dataframe(df)
    st.subheader('Bar Chart')
    fig, ax = plt.subplots(figsize=(6,3.5))
    ax.bar(df['district'], df['risk_prior'])
    ax.set_ylim(0,1); ax.set_ylabel('Risk Prior (0–1)')
    ax.set_xticklabels(df['district'], rotation=30, ha='right')
    st.pyplot(fig)
with col2:
    st.subheader('Quick Scoring')
    text = st.text_area('Paste post/ad text', 'Free stay and food for girls, call 98xxxx immediately')
    district = st.selectbox('District', df['district'].tolist())
    if st.button('Score'):
        try:
            r = requests.post(f'{API_URL}/score', json={'text': text, 'district': district}, timeout=5)
            st.json(r.json())
        except Exception as e:
            st.error(f'API not reachable: {e}')
st.caption('Demo only — replace with authorized data sources.')
