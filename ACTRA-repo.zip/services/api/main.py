
from fastapi import FastAPI
from pydantic import BaseModel
from models.risk_engine import score as risk_score
app = FastAPI(title='ACTRA API', version='0.1')
class ScoreIn(BaseModel):
    text: str
    district: str = 'Chennai'
@app.get('/health')
def health(): return {'status':'ok'}
@app.post('/score')
def score(inp: ScoreIn):
    s = risk_score(inp.text, inp.district)
    tier = 'URGENT' if s>=0.8 else ('INVESTIGATE' if s>=0.6 else 'INFO')
    return {'score': round(s,3), 'tier': tier}
