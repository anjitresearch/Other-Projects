
import networkx as nx
def build_demo_graph():
    G = nx.Graph()
    for n,t in [('user_p1','post'),('user_p4','post'),('recruiter_r1','recruiter'),
                ('phone_98xxxx','phone'),('hub_koyambedu','location')]:
        G.add_node(n, type=t)
    for u,v in [('user_p1','phone_98xxxx'),('user_p4','phone_98xxxx'),
                ('recruiter_r1','phone_98xxxx'),('user_p2','hub_koyambedu')]:
        G.add_edge(u,v)
    return G
if __name__ == '__main__':
    G = build_demo_graph()
    print('nodes', len(G.nodes()), 'edges', len(G.edges()))
